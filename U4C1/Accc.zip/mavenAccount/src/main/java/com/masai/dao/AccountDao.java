package com.masai.dao;

import com.masai.entities.Account;
import com.masai.exception.AccountException;

		public interface AccountDao {
	
		public boolean createAccount(Account account);
	
		public boolean deleteAccount(int accno) throws AccountException;
	
		public boolean updateAccount(Account account);
	
		public Account findAccount(int accno)throws AccountException;

}
