package com.masai.testcases;

import java.util.Scanner;

import com.masai.dao.AccountDao;
import com.masai.dao.AccountDaoImpl;
import com.masai.entities.Account;
import com.masai.exception.AccountException;

public class FindAccount {

	public static void main(String[] args) {
		AccountDao adao = new AccountDaoImpl();
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Enter AccNo:");
		int accNum =scn.nextInt();
		try {
			Account a1 = adao.findAccount(accNum);
			if(a1!=null)
				System.out.println(a1);
			else
				System.out.println("Not Found");
		} catch (AccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
