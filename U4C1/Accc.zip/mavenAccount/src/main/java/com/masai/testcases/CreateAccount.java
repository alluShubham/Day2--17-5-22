package com.masai.testcases;

import java.util.Scanner;

import com.masai.dao.AccountDao;
import com.masai.dao.AccountDaoImpl;
import com.masai.entities.Account;

public class CreateAccount {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the name");
		String name =scn.next();
		
		System.out.println("Enter balance:");
		int balance =scn.nextInt();
		
		AccountDao adao = new AccountDaoImpl();
		Account a1 = new Account();
		a1.setName(name);
		a1.setBalance(balance);
		Boolean flag = adao.createAccount(a1);
		if(flag)
			System.out.println("Your Account is created");
		else
			System.out.println("Not created");
	}

}
