package com.masai.testcases;

import java.util.Scanner;

import com.masai.dao.AccountDao;
import com.masai.dao.AccountDaoImpl;
import com.masai.entities.Account;
import com.masai.exception.AccountException;

public class Withdraw {
	public static void main(String[] args) throws AccountException {
		
		AccountDao adao = new AccountDaoImpl();
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Enter AccNo:");
		int accNum =scn.nextInt();
		
		Account a1 = adao.findAccount(accNum);
		
		if(a1 ==null) {
			System.out.println("Account does not exist..");
		}
		else {
			System.out.println("Enter the Amount to Withdraw :");
			int amt=scn.nextInt();
			
			if(amt <= a1.getBalance()) {
				a1.setBalance(a1.getBalance()-amt);
				Boolean b1 = adao.updateAccount(a1);
				if(b1)
					System.out.println("please collect the cash...");
				else
					System.out.println("Technical Error...");
			}
			else
				System.out.println("Insufficient Amount..");
		}
		
	}

}
