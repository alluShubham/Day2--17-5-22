package com.masai.dao;

import javax.persistence.EntityManager;

import com.masai.entities.Account;
import com.masai.utility.EMUtil;

public class AccountDaoImpl implements AccountDao {

	@Override
	public boolean createAccount(Account account) {
		boolean flag =false;
		EntityManager em = EMUtil.getEntityManager();
		em.getTransaction().begin();
		em.persist(account);
		flag =true;
		em.getTransaction().commit();
		em.close();
		
		return flag;
	}

	@Override
	public boolean deleteAccount(int accno) {
		boolean flag =false;
		EntityManager em = EMUtil.getEntityManager();
		
		Account acc = em.find(Account.class, accno);
		
		if(acc != null) {
		em.getTransaction().begin();
		em.remove(acc);
		flag =true;
		em.getTransaction().commit();
		}
		em.close();
		
		return flag;
	}

	@Override
	public boolean updateAccount(Account account) {
		
		boolean flag =false;
		
		EntityManager em = EMUtil.getEntityManager();
		
		em.getTransaction().begin();
		em.merge(account);
		flag =true;
		em.getTransaction().commit();
		em.close();
		
		return flag;
	}

	@Override
	public Account findAccount(int accno) {
		Account a1 = null;
		EntityManager em = EMUtil.getEntityManager();
		
		em.getTransaction().begin();
		a1= em.find(Account.class, accno);
		em.getTransaction().commit();
		em.close();
		
		return a1;
	}

}
