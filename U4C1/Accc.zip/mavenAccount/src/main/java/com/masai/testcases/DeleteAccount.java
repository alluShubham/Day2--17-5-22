package com.masai.testcases;

import java.util.Scanner;

import com.masai.dao.AccountDao;
import com.masai.dao.AccountDaoImpl;
import com.masai.exception.AccountException;

public class DeleteAccount {

	public static void main(String[] args) throws AccountException {

		AccountDao adao = new AccountDaoImpl();
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Enter AccNo:");
		int accNum =scn.nextInt();
		
		boolean flag = adao.deleteAccount(accNum);
		
		if(flag)
			System.out.println("Your Account remove Succesfully");
		else
			System.out.println("Record not found");

	}

}
