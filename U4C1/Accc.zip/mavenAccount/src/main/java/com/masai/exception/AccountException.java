package com.masai.exception;

public class AccountException extends Exception {
public AccountException() {
		
	}

	public AccountException(String message) {
		super(message);
		
	}

}
